// File: simple_wallet.rs

//! A simple wallet contract to demonstrate deposit and withdrawal logic using Linera Protocol.

use linera_sdk::base::{Amount, Owner};
use linera_sdk::contract::{Contract, ExecutionError};
use linera_sdk::views::{View, ViewStorageContext};
use linera_sdk::contract;

use std::collections::BTreeMap;

/// State of the wallet contract
#[derive(View, Default)]
pub struct WalletState {
    /// Maps each user to their token balance
    pub balances: BTreeMap<Owner, Amount>,
}

/// Enum representing user operations
#[derive(serde::Deserialize)]
pub enum WalletOperation {
    Deposit(Amount),
    Withdraw(Amount),
}

/// The main wallet contract
pub struct WalletApp {
    pub state: WalletState,
}

#[contract]
impl Contract for WalletApp {
    type State = WalletState;

    fn instantiate(&mut self, _params: Vec<u8>) -> Result<(), ExecutionError> {
        self.state = WalletState::default();
        Ok(())
    }

    fn execute_operation(&mut self, operation: Vec<u8>) -> Result<(), ExecutionError> {
        let caller = self.authenticated_signer()?;
        let op: WalletOperation = bcs::from_bytes(&operation)?;
        match op {
            WalletOperation::Deposit(amount) => {
                *self.state.balances.entry(caller).or_default() += amount;
            }
            WalletOperation::Withdraw(amount) => {
                let balance = self.state.balances.entry(caller).or_default();
                if *balance < amount {
                    return Err(ExecutionError::UserError("Insufficient balance".into()));
                }
                *balance -= amount;
            }
        }
        Ok(())
    }
}
